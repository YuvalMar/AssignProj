
<?php require_once("parts/header.php"); ?>
<?php
       require_once("db.php");
       $user = $_SESSION['User_Email'];
       $sql = "SELECT * FROM usersgroup WHERE groupId NOT IN(SELECT gid FROM user_in_group WHERE user='$user')";
       $result = $conn->query($sql);
       $groups = array();
       while($row = $result->fetch_assoc()){
           $groups[]=$row;
       }
?>

<title>Join group</title>
  </head>

  <body>
    <h1 style="text-align:center">You can join one of this team</h1>
    <div id="slct">
      <form method="POST">
    <select name="groups" id="groups" multiple>
      <?php foreach($groups as $g):?>
      <option value="<?=$g['groupId']?>"><?=$g['groupId']?></option>
      <?php endforeach;?>
  </select>
    </div>
  <div id="slct">
    <button id="slctSubmit" class="btn btn-primary" type="submit">Submit Selection</button>
  </div>
  </form>
  </body>
  <?php require_once("parts/footer.php");?>
</html>

<style>
    select {
        width: 150px;
        margin: 10px;
        text-align:center;
    }
    select:focus {
        min-width: 150px;
        width: auto;
    }

    #slct {
      text-align : center;
    }
</style>

<script>
    $("#myLogo").attr('href', 'index.php');
</script>