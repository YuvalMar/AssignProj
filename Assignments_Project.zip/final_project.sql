-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: יולי 21, 2021 בזמן 07:17 PM
-- גרסת שרת: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `final_project`
--

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `assignments`
--

CREATE TABLE `assignments` (
  `id` int(11) NOT NULL,
  `title` varchar(25) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `completed` tinyint(1) NOT NULL,
  `dest_date` date NOT NULL,
  `groupId` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- הוצאת מידע עבור טבלה `assignments`
--

INSERT INTO `assignments` (`id`, `title`, `created_by`, `completed`, `dest_date`, `groupId`) VALUES
(28, 'test', 'dorber9@gmail.com', 0, '2021-07-15', 2),
(29, 'hw1', 'asd@abs.com', 0, '2021-07-23', 31),
(30, 'new', 'a@b.com', 0, '2021-07-29', 31),
(32, 'nasasn', 'test@test.com', 1, '2021-07-09', 31),
(35, 'bvbv', 'a@b.com', 0, '2021-07-21', NULL),
(36, 'hatsaga', 'test@test.com', 0, '2021-07-28', 42),
(37, 'new42', 'test@test.com', 0, '2021-07-25', 42),
(38, 'dssad', 'test@test.com', 0, '2021-08-01', 31);

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `users`
--

CREATE TABLE `users` (
  `user_email` varchar(50) NOT NULL,
  `user_pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- הוצאת מידע עבור טבלה `users`
--

INSERT INTO `users` (`user_email`, `user_pass`) VALUES
('a@a.com', '123456'),
('a@b.com', '123456'),
('asd@abs.com', '123'),
('asd@asd.com', '123'),
('dorber9@gmail.com', '123456'),
('test@test.com', '123'),
('yakov@y.com', '123');

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `usersgroup`
--

CREATE TABLE `usersgroup` (
  `groupId` tinyint(4) NOT NULL,
  `manager` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- הוצאת מידע עבור טבלה `usersgroup`
--

INSERT INTO `usersgroup` (`groupId`, `manager`) VALUES
(2, 'asd@abs.com'),
(31, 'dorber9@gmail.com'),
(42, 'test@test.com');

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `userstokens`
--

CREATE TABLE `userstokens` (
  `email` varchar(50) NOT NULL,
  `token` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `user_in_group`
--

CREATE TABLE `user_in_group` (
  `gid` tinyint(4) NOT NULL,
  `user` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- הוצאת מידע עבור טבלה `user_in_group`
--

INSERT INTO `user_in_group` (`gid`, `user`) VALUES
(31, 'dorber9@gmail.com'),
(31, 'test@test.com'),
(42, 'a@b.com'),
(42, 'test@test.com'),
(42, 'yakov@y.com');

--
-- Indexes for dumped tables
--

--
-- אינדקסים לטבלה `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `groupId` (`groupId`);

--
-- אינדקסים לטבלה `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_email`),
  ADD KEY `user_email` (`user_email`);

--
-- אינדקסים לטבלה `usersgroup`
--
ALTER TABLE `usersgroup`
  ADD PRIMARY KEY (`groupId`,`manager`),
  ADD UNIQUE KEY `manager` (`manager`);

--
-- אינדקסים לטבלה `userstokens`
--
ALTER TABLE `userstokens`
  ADD PRIMARY KEY (`email`);

--
-- אינדקסים לטבלה `user_in_group`
--
ALTER TABLE `user_in_group`
  ADD PRIMARY KEY (`gid`,`user`),
  ADD KEY `user` (`user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `usersgroup`
--
ALTER TABLE `usersgroup`
  MODIFY `groupId` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `user_in_group`
--
ALTER TABLE `user_in_group`
  MODIFY `gid` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- הגבלות לטבלאות שהוצאו
--

--
-- הגבלות לטבלה `assignments`
--
ALTER TABLE `assignments`
  ADD CONSTRAINT `assignments_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_email`),
  ADD CONSTRAINT `assignments_ibfk_2` FOREIGN KEY (`groupId`) REFERENCES `usersgroup` (`groupId`);

--
-- הגבלות לטבלה `usersgroup`
--
ALTER TABLE `usersgroup`
  ADD CONSTRAINT `usersgroup_ibfk_1` FOREIGN KEY (`manager`) REFERENCES `users` (`user_email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- הגבלות לטבלה `user_in_group`
--
ALTER TABLE `user_in_group`
  ADD CONSTRAINT `user_in_group_ibfk_2` FOREIGN KEY (`user`) REFERENCES `users` (`user_email`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_in_group_ibfk_3` FOREIGN KEY (`gid`) REFERENCES `usersgroup` (`groupId`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
