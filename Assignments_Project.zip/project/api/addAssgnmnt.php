<?php
        require_once("../db.php");
        if(!isset($_GET['gid'])){
            $title = $_GET['title'];
            $by = $_GET['created_by'];
            $completed = '0';
            $dest = $_GET['dest_date'];
            $sql = "INSERT INTO `assignments`(`title`, `created_by`, `completed`, `dest_date`)
            VALUES ('$title', '$by', '$completed', '$dest')";
            if($conn->query($sql) === TRUE){
                header('Location: ../assignments.php');
                exit;
            }
            else{ 
            header('Location: ../assignments.php');
            exit;
            }
        }
        else{
            $title = $_GET['title'];
            $by = $_GET['created_by'];
            $completed = '0';
            $dest = $_GET['dest_date'];
            $gid = $_GET['gid'];
            $sql = "INSERT INTO `assignments`(`title`, `created_by`, `completed`, `dest_date`, `groupId`)
            VALUES ('$title', '$by', '$completed', '$dest', '$gid')";
            if($conn->query($sql) === TRUE){
                header('Location: ../groupAssignments.php');
                exit;
            }
            else{ 
            header('Location: ../assignments.php');
            exit;
            }
        }
    
$conn->close();