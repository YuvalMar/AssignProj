<?php session_start();?>
<?php
require_once("../db.php");
 
        $user_email = $_SESSION['User_Email'];
        $sql = "INSERT INTO `usersgroup`(`manager`)
        VALUES ('$user_email')";
        if($conn->query($sql) === TRUE){
            echo json_encode(array('success' => 1));
        }
        else  
           echo json_encode(array('success' => 0));
      
           $sql = "SELECT groupId FROM usersgroup WHERE manager='$user_email'";
           $result = $conn->query($sql);
           $res = $result->fetch_assoc();  
           $gid = $res['groupId'];
           $sql = "INSERT INTO `user_in_group`(`gid`, `user`)
        VALUES ('$gid', '$user_email' )";
        $conn->query($sql);
          
$conn->close();

