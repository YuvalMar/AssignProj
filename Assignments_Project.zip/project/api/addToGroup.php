<?php session_start(); ?>
<?php
require_once("../db.php");
        $user = $_SESSION["User_Email"];
        $gid = $_GET['gid'];
        $sql = "INSERT INTO `user_in_group`(`gid`, `user`)
        VALUES ('$gid', '$user')";
        if($conn->query($sql) === TRUE){
            echo json_encode(array('success' => 1));
        }
        else  
           echo json_encode(array('success' => 0));
    
$conn->close();