<?php  
    require_once('../db.php');
    $id=$_GET['id'];
    $sql = "DELETE FROM assignments WHERE id=$id";
    if($conn->query($sql) === TRUE){
        $last_id = $conn->insert_id;
        echo json_encode(array('success' => 1, "id"=>$last_id));
        header('Location: ../assignments.php');
        exit;
    }
    else{
        header('Location: ../assignments.php');
        exit;
        echo json_encode(array('success' => 0));
    }
