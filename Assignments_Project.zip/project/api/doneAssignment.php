<?php
        require_once("../db.php");
        $aid = $_GET['aid'];
        $completed = $_GET['completed'];
        $sql = "UPDATE assignments
        SET `completed` = $completed
        WHERE `id`='$aid'";
        if($conn->query($sql) === TRUE){
          header('Location: ' . $_SERVER['HTTP_REFERER']);
             exit;
        }
        else{ 
          header('Location: ' . $_SERVER['HTTP_REFERER']);
             exit;
        }