<?php
        require_once("../db.php");
        $aid = $_GET['aid'];
        $title = $_GET['title'];
        $by = $_GET['created_by'];
        $completed = '0';
        $dest = $_GET['dest_date'];
        if(isset($_GET['gid'])){
             $gid = $_GET['gid'];
             $sql = "UPDATE assignments
             SET `title`='$title', `created_by`='$by', `completed` = $completed, `dest_date` = '$dest', `groupId`='$gid'
             WHERE `id`='$aid'";
        }
        else{
          $sql = "UPDATE assignments
          SET `title`='$title', `created_by`='$by', `completed` = $completed, `dest_date` = '$dest'
          WHERE `id`='$aid'";
        }
        if($conn->query($sql) === TRUE){
          header('Location: ' . $_SERVER['HTTP_REFERER']);
          exit;
        }
        else{ 
          header('Location: ' . $_SERVER['HTTP_REFERER']);
          exit;
        }

