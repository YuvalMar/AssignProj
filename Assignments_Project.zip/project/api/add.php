
<?php
require_once("../db.php");
 
        $user_email = $_POST['user_email'];
        $user_pass = $_POST['user_pass'];
        $sql = "INSERT INTO `users`(`user_email`, `user_pass`)
        VALUES ('$user_email', '$user_pass')";
        if($conn->query($sql) === TRUE){
            echo json_encode(array('success' => 1));
        }
        else  
           echo json_encode(array('success' => 0));
    
$conn->close();

