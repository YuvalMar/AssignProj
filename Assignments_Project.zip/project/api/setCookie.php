<?php
require_once("../db.php");
 
        $user_email = $_GET['email'];
        $token = $_GET['token'];
        $sql = "INSERT INTO `userstokens`(`email`, `token`)
        VALUES ('$user_email', '$token')";
        if($conn->query($sql) === TRUE){
           header("Location: ../assignments.php");
        }
        else  
            header("Location: ../assignments.php");
    
$conn->close();