<?php
$servername = "localhost";
$username = "root";
$password = "";

$conn = new mysqli($servername,$username,$password );

if($conn->connect_error)
    die("Connection failed: ".$conn->connect_errot);

$dbName = "final_project";

if(!mysqli_select_db($conn,$dbName)){
    $sql = "CREATE DATABASE $dbName";
    if($conn->query($sql) === TRUE)
        echo "Database Created Successfully";
    else
        echo "Error Creating database ".$conn->error;   
}

$conn = new mysqli($servername, $username, $password, $dbName);

$sql = " SELECT user_email FROM users";
if(!$conn->query($sql)){
    $sql = "CREATE TABLE users(`user_email` VARCHAR(50) PRIMARY KEY,
    `user_pass` VARCHAR(50)";
    if($conn->query($sql) === TRUE)
        echo "Table Users Created Successfully";
    else  
        echo "Error Creating table: " . $conn->error;  
}
