<?php 
    session_start();
    $email = $_SESSION['User_Email'];
    $_SESSION=[];
    session_destroy();
    setcookie("User_Email",$user_email,strtotime('-7 days'));
    setcookie("token",$token,strtotime('-7 days'));
    header("Location: api/eraseCookie.php?email=$email");
    exit;
    ?>