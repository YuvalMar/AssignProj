<?php
        session_start();
        require_once("../db.php");
        $user_email = $_SESSION['rstEmail'];
        $user_pass = $_POST["newPass"];
        $sql = "UPDATE users
        SET `user_pass`='$user_pass'
        WHERE `user_email`='$user_email'";
        if($conn->query($sql) === TRUE)
            echo json_encode(array('success' => 1));
        else
            echo json_encode(array('success' => 0));


    
    