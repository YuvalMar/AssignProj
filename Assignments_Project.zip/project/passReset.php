<?php require_once("parts/header.php");?>
<?php
       require_once("db.php");
       $sql = "SELECT * FROM users";
       $result = $conn->query($sql);
       $users = array();
       while($row = $result->fetch_assoc()){
           $users[]=$row;
       }
       $conn->close();
       $users1 = array();
       foreach ($users as $u){
           $users1[$u["user_email"]] = $u["user_pass"];
       }
       if(isset($_POST['resetEmail'])){
          if(isset($users1[$_POST['resetEmail']])){
              $_SESSION['rstEmail'] = $_POST['resetEmail'];
              header('Location: passRst1.php');
              exit;
          }
       }
?>

    <title>Reset Password</title>
  </head>

  <body>
    <div class="container">
      <h1>Reset Password</h1>
      <hr />
      <form method="POST" id="passRstForm">
        <label for="resetEmail"><b>Email</b></label>
        <input
          type="text"
          placeholder="Enter Email"
          name="resetEmail"
          id="resetEmail"
          required
        />

        <button type="submit" class="registerbtn" >
          Reset
        </button>
        </form>
    </div>
  </body>
  <?php require_once("parts/footer.php");?>
</html>

<style>
    body {
      font-family: 'Varela Round', sans-serif;
      background-color: black;
    }

    * {
      box-sizing: border-box;
    }

    /* Add padding to containers */
    .container {
      padding: 16px;
    }

    /* Full-width input fields */
    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
    }

    input[type="text"]:focus,
    input[type="password"]:focus {
      background-color: #ddd;
      outline: none;
    }

    /* Overwrite default styles of hr */
    hr {
      border: 1px solid #f1f1f1;
      margin-bottom: 25px;
    }

    /* Set a style for the submit button */
    .registerbtn {
      background-color: #4caf50;
      color: white;
      padding: 16px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 100%;
      opacity: 0.9;
    }

    .registerbtn:hover {
      opacity: 1;
    }

    /* Add a blue text color to links */
    a {
      color: rgb(0, 54, 107);
    }

    /* Set a grey background color and center the text of the "sign in" section */
    .signin {
      text-align: center;
    }
  </style>

<script>
    $("#lgOut").css("visibility", "hidden");
    $("#myLogo").attr('href', 'index.php');
</script>