var indexEmail = document.getElementById("emailAdd");
var indexPass = document.getElementById("floatingPassword");
var username = document.getElementById("username");
var signEmail = document.getElementById("email");
var emailCon = document.getElementById("emailConfirmation");
var signPass = document.getElementById("psw");
var passCon = document.getElementById("psw-repeat");
var resetEmail = document.getElementById("resetEmail");
var currentRow;
var flag = 0;

var vueApp = new Vue({
  el: "#app",
  data() {
    return {
      assignment: {
        title: "",
        by: "",
        date: "",
        gid: "",
      },
    };
  },
});

$(document).ready(function () {
  $("#addUsersForm").submit(function (e) {
    e.preventDefault();
    if (
      $("#user_email").val() == $("#emailConfirmation").val() &&
      $("#user_pass").val() == $("#psw-repeat").val()
    ) {
      $.ajax({
        type: "POST",
        url: "api/add.php",
        data: $(this).serialize(),
        success: function (response) {
          var jsonData = JSON.parse(response);
          if (jsonData.success == "1") {
            alert("You have signed up successfully!");
            window.location.href = "index.php";
          } else {
            alert("Email already registered!");
          }
        },
      });
    } else alert("One of the fields does not match!");
  });

  $("#passRstForm1").submit(function (e) {
    e.preventDefault();
    $.ajax({
      type: "POST",
      url: "api/resetPass.php",
      data: $(this).serialize(),
      success: function (response) {
        var jsonData = JSON.parse(response);
        if (jsonData.success == "1") {
          alert("Password changed Successfully");
          window.location.href = "index.php";
        } else alert("Something Went Wrong");
      },
    });
  });
  //A function that changes the graphics according to checkbox statement
  $(document).on("click", ".checkbox", function () {
    if (this.checked) {
      $(this).parents("tr").children().css("text-decoration", "line-through");
      $(this).parents("tr").children().css("color", "green");
      $aid = $(this).parents("tr").attr("data-id");
      window.location.href = "api/doneAssignment.php?completed=1&aid=" + $aid;
    } else {
      $(this).parents("tr").children().css("text-decoration", "none");
      $(this).parents("tr").children().css("color", "black");
      $aid = $(this).parents("tr").attr("data-id");
      window.location.href = "api/doneAssignment.php?completed=0&aid=" + $aid;
    }
  });
  //Delete Row function+update the values of titles list and assignements list
  $("#mytbl").on("click", "#deleteBtn", function () {
    let title = $(this).parents("tr").find("td").html();
    $("#dltH2").html("You are about to delete " + title);
    $("#DeleteA").trigger("click");
    old = $(this).parents("tr");
    id = $(this).parents("tr").data("id");
    $("#deleteAssnmnt").click(function () {
      window.location.href = "api/deleteAsgnmnt.php?id=" + id;
    });
  });

  $("#mymodal").on("hidden.bs.modal", function (e) {
    vueApp.assignment.title = "";
    vueApp.assignment.by = "";
    vueApp.assignment.date = "";
    $("#title").val("");
    $("#created_by").val("");
    $("#dest_date").val("");
  });

  $("#slctSubmit").click(function (e) {
    e.preventDefault();
    $flag = 1;
    $("#groups option:selected").each(function () {
      $currGid = $(this).text();
      $.ajax({
        type: "POST",
        url: "api/addToGroup.php?gid=" + $currGid,
        data: $(this).serialize(),
        success: function (response) {
          var jsonData = JSON.parse(response);
          if (jsonData.success == "1") {
            $flag = 1;
          } else $flag = 0;
        },
      });
    });
    window.location.href = "index.php";
  });

  $("#navE1").click(function (e) {
    e.preventDefault();
    $.ajax({
      type: "POST",
      url: "api/createGroup.php",
      data: $(this).serialize(),
      success: function (response) {
        var jsonData = JSON.parse(response);
        if (jsonData.success == "0") {
          alert(
            "Something Went Wrong.Group might already exist for your user."
          );
        } else if (jsonData.success == "1") {
          alert("Group created successfully!");
          window.location.href = "index.php";
        }
      },
    });
  });

  $("#personalPage").click(function () {
    window.location.href = "assignments.php";
  });

  $("#goToGroup").click(function () {
    window.location.href = "groupAssignments.php";
  });
});

// Function for password reset page
function passReset() {
  if (resetEmail.value == "") alert("Please enter an email address!");
  else {
    if (validateEmail(resetEmail.value) == false)
      alert("Please enter a valid email address");
    else {
      alert("We sent instruction to your email address");
      window.location.href = "index.php";
    }
  }
}

// Function to validate the email address
function validateEmail(email) {
  const re =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
}

var oldtitle;
var loc;
var aaid;
function editRow(row, aid) {
  if (document.URL.includes("group")) {
    document.querySelector("#EditAssign").click();
    currentRow = row;
    let title = document.querySelector("#titleEdit");
    let by = document.querySelector("#ByEdit");
    let date = document.querySelector("#dateAddEdit");
    let gid = document.querySelector("#groupIdEdit");
    aaid = aid;
    gid.value = mytbl.rows[currentRow].cells[0].innerHTML;
    title.value = mytbl.rows[currentRow].cells[1].innerHTML;
    by.value = mytbl.rows[currentRow].cells[2].innerHTML;
    date.value = mytbl.rows[currentRow].cells[5].innerHTML;
  } else {
    document.querySelector("#EditAssign").click();
    currentRow = row;
    let title = document.querySelector("#titleEdit");
    let by = document.querySelector("#ByEdit");
    let date = document.querySelector("#dateAddEdit");
    aaid = aid;
    title.value = mytbl.rows[currentRow].cells[0].innerHTML;
    by.value = mytbl.rows[currentRow].cells[1].innerHTML;
    date.value = mytbl.rows[currentRow].cells[4].innerHTML;
  }
}

function saveEdit() {
  if (document.URL.includes("group")) {
    let title = document.querySelector("#titleEdit");
    let by = document.querySelector("#ByEdit");
    let date = document.querySelector("#dateAddEdit");
    let gid = document.querySelector("#groupIdEdit");
    let vars =
      "?aid=" +
      aaid +
      "&title=" +
      title.value +
      "&created_by=" +
      by.value +
      "&dest_date=" +
      date.value +
      "&gid=" +
      gid.value;
    loc = "api/editAssgnmnt.php" + vars;
  } else {
    let title = document.querySelector("#titleEdit");
    let by = document.querySelector("#ByEdit");
    let date = document.querySelector("#dateAddEdit");
    let vars =
      "?aid=" +
      aaid +
      "&title=" +
      title.value +
      "&created_by=" +
      by.value +
      "&dest_date=" +
      date.value;
    loc = "api/editAssgnmnt.php" + vars;
  }
  window.location.href = loc;
}
function convertDate(d) {
  var p = d.split("-");
  return +(p[0] + p[1] + p[2]);
}

function sortByDate() {
  var tbody = document.querySelector("#mytbl tbody");
  // get trs as array for ease of use
  var rows = [].slice.call(tbody.querySelectorAll("tr"));
  if (document.URL.includes("group")) {
    rows.sort(function (a, b) {
      return (
        convertDate(a.cells[5].innerHTML) - convertDate(b.cells[5].innerHTML)
      );
    });
  }
  rows.sort(function (a, b) {
    return (
      convertDate(a.cells[4].innerHTML) - convertDate(b.cells[4].innerHTML)
    );
  });
  rows.forEach(function (v) {
    tbody.appendChild(v); // note that .appendChild() *moves* elements
  });
}

function sortByTitle() {
  var tbody = document.querySelector("#mytbl tbody");
  // get trs as array for ease of use
  var rows = [].slice.call(tbody.querySelectorAll("tr"));
  if (document.URL.includes("group")) {
    rows.sort(function (a, b) {
      if (a.cells[1].innerHTML < b.cells[1].innerHTML) {
        return -1;
      }
      if (a.cells[1].innerHTML > b.cells[1].innerHTML) {
        return 1;
      }
      return 0;
    });
  } else {
    rows.sort(function (a, b) {
      if (a.cells[0].innerHTML < b.cells[0].innerHTML) {
        return -1;
      }
      if (a.cells[0].innerHTML > b.cells[0].innerHTML) {
        return 1;
      }
      return 0;
    });
  }
  rows.forEach(function (v) {
    tbody.appendChild(v); // note that .appendChild() *moves* elements
  });
}
