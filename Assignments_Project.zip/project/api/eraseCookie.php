<?php
    session_start();
    require_once('../db.php');
    $email=$_GET['email'];
    $sql = "DELETE FROM userstokens WHERE email='$email'";
    if($conn->query($sql) === TRUE){
        header('Location: ../index.php');
        exit;
    }
    else{
        header('Location: ../index.php');
        exit;
    }
