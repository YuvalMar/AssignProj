
<?php require_once("parts/header.php"); ?>
<?php
       require_once("db.php");
       $uEmail = $_SESSION["User_Email"];
       $sql = "SELECT * FROM assignments WHERE created_by='$uEmail' GROUP BY title";
       $result = $conn->query($sql);
       $assignments = array();
       while($row = $result->fetch_assoc()){
           $assignments[]=$row;
       }

       $sql = "SELECT * FROM users";
       $result = $conn->query($sql);
       $users = array();
       while($row = $result->fetch_assoc()){
           $users[]=$row;
       }
       $conn->close();
?>

<!-- Php for adding new assignment -->
<?php 
    if(isset($_POST['title'])){
        if(!empty($_POST['created_by']) && !empty($_POST['dest_date']) && !empty($_POST['title'])){
            require_once("db.php");
            $title = $_POST['title'];
            $by = $_POST['created_by'];
            $dest = $_POST['dest_date'];
            $vars = "?title=$title&created_by=$by&dest_date=$dest";
            $loc = "Location: api/addAssgnmnt.php$vars";
            header($loc);
        }
        else
            echo '<script>alert("You have to fill all the fields!")</script>';
    }
?>

<!-- Php for editing -->
<?php 
    if(isset($_POST['titleEdit'])){
        require_once("db.php");
        $title = $_POST['titleEdit'];
        $by = $_POST['ByEdit'];
        $dest = $_POST['dateAddEdit'];
        $vars = "?title=$title&created_by=$by&dest_date=$dest";
        $loc = "Location: api/editAssgnmnt.php$vars";
        header($loc);
    }
?>
    <title>Assignments</title>
</head>



<body>
<div id="app">
    <div class="container">
        <div class="col" id="testing">
            <h1 style="text-align: center;">Assignments</h1>
        </div>
        <p style="text-align: center;">This is your personal assignments page.</p>
        <hr />
        <table class="table table-hover table-striped table-dark" id="mytbl">

            <thead class="thead-dark">
                <tr>
                    <div class="row"></div>
                    <th style="cursor: pointer;" onclick="sortByTitle()" scope="col">Title <i class="fas fa-arrow-down"></i></th>
                    <th scope="col">In charge</th>
                    <th scope="col">Completed</th>
                    <th scope="col">Edit</th>
                    <th style="cursor: pointer;" onclick="sortByDate()" scope="col">Destination Date <i class="fas fa-arrow-down"></i></th>
                    <th scope="col">Delete</th>
    </div>
    </tr>
    </thead>
    <tbody class="table-info">
    <?php 
    $x=1;
    foreach($assignments as $a):?>
    <?php $thisId =  $a['id'];?>
        <?php if($a['completed']==true)
         echo "<tr style='text-decoration:line-through; color:green;' data-id='$thisId'>";
            else
                echo "<tr data-id='$thisId'>";?>
            <td class="title"><?=$a["title"];?></td>
            <td class="by"><?=$a["created_by"];?></td>
            <?php 
                if ($a['completed']==true)
                    echo "<td><input type='checkbox'  checked id='ChkBox$x' class='checkbox' ></td>";
                 else
                     echo "<td><input type='checkbox' id='ChkBox$x' class='checkbox'></td>"; ?>
            <td>
                <button id="assgnmntEdit" onclick="editRow(<?=$x?>, <?=$a['id'];?>)" class="btn btn-primary" type="button">
                    Edit
                </button>
            </td>
            <td class="dest_date"><?=$a["dest_date"];?></td>
            <td>
                <button class="btn btn-danger" type="Delete" id=deleteBtn>Delete</button>
            </td>
        </tr>
        <?php $x++?>
        <?php endforeach;?>
        <tr id="notTr" v-if="assignment.title"> 
            <td v-if="assignment.title"> {{assignment.title}}</td>
            <td v-if="assignment.by"> {{assignment.by}}</td>
            <td v-if="assignment.by"><input type='checkbox' class='checkbox'></td>
            <td v-if="assignment.by"><button id="assgnmntEdit"  class="btn btn-primary" type="button">Edit </button></td>
            <td v-if="assignment.date">{{assignment.date}}</td>
            <td v-if="assignment.by"><button class="btn btn-danger" type="Delete" id=deleteBtn>Delete</button></td>
        </tr>
        
    </tbody>
    </table>
    
    <div id="commentSection"></div>

    <div class="container" id="addBtn">
        <button class="btn btn-primary" style="text-align: center" type="button" data-bs-toggle="modal" data-bs-target="#mymodal" id="add">
            Add Assignment
        </button>
    </div>

    <div class="container" id="groupPage">   
        <button id="goToGroup"  value="Go to group assignments" type="submit" class="btn btn-primary" style="text-align: center"  href="groupAssignments.php">
        Go to group assignments    
    </button>
    </div>

    <button type="button" data-bs-toggle="modal" data-bs-target="#mymodalEdit" id="EditAssign">
        Edit Assignment
    </button>

    <button type="button" data-bs-toggle="modal" data-bs-target="#mymodalDelete" id="DeleteA">
        Delete Assignment
    </button>
    
    <!-- ADD ASSIGNMENTS MODAL -->
    <div id="mymodal" class="modal" tabindex="-1" autocomplete="off" action="/action_page.php">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Assignment</h5>
                    </div>
                    <div class="modal-body" id="mdbody">
                    <form id="addForm" method="POST">
                        <div class="mb-3">
                            <fieldset>
                            <label for="title" class="form-label">Title</label>
                            <input required autocomplete="off" list="assignmentsList" v-model="assignment.title" class="form-control" placeholder="Assignment title" id="title" name="title" type="text"></input>
                            <datalist id="assignmentsList">
                                <?php foreach($assignments as $a):?>
                                <option value="<?=$a['title'];?>">
                                <?php endforeach;?>
                             </datalist>
                        </div>
                        <div class="mb-3">
                            <label for="created_by" class="form-label">In charge</label>
                            <input required value="<?=$_SESSION['User_Email']?>" autocomplete="off" list="usersList" v-model="assignment.by" class="form-control" id="created_by" name="created_by" placeholder="By"></input>
                            <datalist id="usersList">
                                <?php foreach($users as $u):?>
                                    
                                <option value="<?=$u['user_email'];?>">
                                
                                <?php endforeach;?>
                            </datalist>
                        </div>
                        <div class="mb-3">
                            <label v-model="assignment.date" for="dest_date" class="form-label">Destination Date </label>
                            <br />
                            <input required type="date" id="dest_date" name="dest_date" />
                        </div>
                    </div>
                    </fieldset>
                    <div class="modal-footer">
                        <button id="cancelBtn" type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            Close
                        </button>
                        <button id="saveChng" type="submit" class="btn btn-primary">
                            Add
                        </button>
                    </div>
                    </form>
                </div>
            </div>
    </div>
        <!-- ADD ASSIGNMENTS MODAL FINISH -->

    <!-- EDIT ASSIGNMENTS MODAL -->
    
    <div id="mymodalEdit" class="modal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Assignment</h5>
                    </div>
                    <div class="modal-body" id="mdbody">
                    <form id="editForm" method="POST">
                    <div class="mb-3">
                        <input class="form-control" id="rowId" name="rowId" style="display:none;" type="text" ></input>
                        </div>
                        <div class="mb-3">
                            <label for="titleEdit" class="form-label">Title</label>
                            <input required list="assignmentsListEdit" autocomplete="off" class="form-control" placeholder="Assignment title" id="titleEdit" name="titleEdit" type="text"></input>
                            <datalist id="assignmentsListEdit">
                                <?php foreach($assignments as $a):?>
                                <option value="<?=$a['title'];?>">
                                <?php endforeach;?>
                             </datalist>
                        </div>
                        <div class="mb-3">
                            <label for="ByEdit" class="form-label">In charge</label>
                            <input required list="usersListEdit" autocomplete="off" class="form-control" id="ByEdit" name="ByEdit" placeholder="By"></input>
                            <datalist id="usersListEdit">
                                <?php foreach($users as $u):?>
                                    
                                <option value="<?=$u['user_email'];?>">
                                
                                <?php endforeach;?>
                            </datalist>
                        </div>
                        <div class="mb-3">
                            <label for="dateAddEdit" class="form-label">Destination Date </label>
                            <br />
                            <input required type="date" id="dateAddEdit" name="dateAddEdit" />
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="editClose" type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            Close
                        </button>
                        <button id="editSub" onclick="saveEdit()" type="button" class="btn btn-primary">
                        Save changes
                        </button>
                    </div>
                    </form>
                </div>
            </div>
    </div>
        <!-- EDIT ASSIGNMENTS MODAL FINISH -->

        <!-- DELETE ASSIGNMENTS MODAL -->
    <div id="mymodalDelete" class="modal" tabindex="-1">
        <form method="POST">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header flex-column">
                        <div class="icon-box">
                            <i class="material-icons">&#xE5CD;</i>
                        </div>
                        <h5 class="modal-title w-100">Delete Assignment ?</h5>
                    </div>
                    <div class="modal-body" id="mdbody">
                        <h2 id="dltH2" style="text-align: center;">Are you sure you want to delete</h2>
                    </div>
                    <div class="modal-footer justify-content-center">
                        <button id="dltCncl" type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            Cancel
                        </button>
                        <button id="deleteAssnmnt" type="submit" class="btn btn-danger" data-bs-dismiss="modal">
                            Delete
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
        <!-- DELETE ASSIGNMENTS MODAL FINISH -->
</body>
</div>

<?php require_once("parts/footer.php");?>


<style>
    body {
        font-family: 'Varela Round', sans-serif;
    }
    
    .modal-dialog {
    margin-top: 1%;
    margin-left: 50%;
    }

    .modal-confirm {
        color: #636363;
        width: 400px;
    }
    
    .modal-confirm .modal-content {
        padding: 20px;
        border-radius: 5px;
        border: none;
        text-align: center;
        font-size: 14px;
    }
    
    .modal-confirm .modal-header {
        border-bottom: none;
        position: relative;
    }
    
    .modal-confirm h4 {
        text-align: center;
        font-size: 26px;
        margin: 30px 0 -10px;
    }
    
    .modal-confirm .close {
        position: absolute;
        top: -5px;
        right: -2px;
    }
    
    .modal-confirm .modal-body {
        color: #999;
    }
    
    .modal-confirm .modal-footer {
        border: none;
        text-align: center;
        border-radius: 5px;
        font-size: 13px;
        padding: 10px 15px 25px;
    }
    
    .modal-confirm .modal-footer a {
        color: #999;
    }
    
    .modal-confirm .icon-box {
        width: 80px;
        height: 80px;
        margin: 0 auto;
        border-radius: 50%;
        z-index: 9;
        text-align: center;
        border: 3px solid #f15e5e;
    }
    
    .modal-confirm .icon-box i {
        color: #f15e5e;
        font-size: 46px;
        display: inline-block;
        margin-top: 13px;
    }
    
    .modal-confirm .btn,
    .modal-confirm .btn:active {
        color: #fff;
        border-radius: 4px;
        background: #60c7c1;
        text-decoration: none;
        transition: all 0.4s;
        line-height: normal;
        min-width: 120px;
        border: none;
        min-height: 40px;
        border-radius: 3px;
        margin: 0 5px;
    }
    
    .modal-confirm .btn-secondary {
        background: #c1c1c1;
    }
    
    .modal-confirm .btn-secondary:hover,
    .modal-confirm .btn-secondary:focus {
        background: #a8a8a8;
    }
    
    .modal-confirm .btn-danger {
        background: #f15e5e;
    }
    
    .modal-confirm .btn-danger:hover,
    .modal-confirm .btn-danger:focus {
        background: #ee3535;
    }
    
    .trigger-btn {
        display: inline-block;
        margin: 100px auto;
    }
</style>
</html>

<script>
    $(document).ready(function(){
        $("#navE").css("visibility", "visible");
        $("#navE1").css("visibility", "visible");
    })
</script>