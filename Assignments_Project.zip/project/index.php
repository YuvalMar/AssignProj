<?php require_once("parts/header.php");?>
<?php
       require_once("db.php");
       $sql = "SELECT * FROM users";
       $result = $conn->query($sql);
       $users = array();
       while($row = $result->fetch_assoc()){
           $users[]=$row;
       }
       
       $users1 = array();
       foreach($users as $u){
           $users1[$u["user_email"]] = $u["user_pass"];
       }

       $sql = "SELECT * FROM userstokens";
       $result = $conn->query($sql);
       $usersAndTokens = array();
       while($row = $result->fetch_assoc()){
            $usersAndTokens[]=$row;
        }
        $userTokenVal = array();
        foreach($usersAndTokens as $us){
            $usersTokenVal[$us['email']] = $us['token'];
        }
       $conn->close();
?>
<?php 
  if(isset($_COOKIE['User_Email'])){
    if($_COOKIE['token']==$usersTokenVal[$_COOKIE['User_Email']])
        $_SESSION['User_Email']=$_COOKIE['User_Email'];
  }
?>
<?php 
  if(isset($_SESSION["User_Email"])){
    header('Location: assignments.php');
    exit;
  }
?>

<?php
    if(isset($_POST['user_email'])){

    $user_email = $_POST['user_email'];
    $user_password = $_POST['user_pass'];
    $save_password = $_POST['save_pass'];
    
    if(isset($users1[$user_email])){
        if($users1[$user_email]==$user_password){
            $_SESSION["User_Email"]=$user_email;
            if($save_password=="on"){
                setcookie("User_Email",$user_email,strtotime('+7 days'));
                $token = bin2hex(random_bytes(16));
                setcookie("token", $token, strtotime('+7 days'));
                $vars = "email=$user_email&token=$token";
                header("Location: api/setCookie.php?$vars");
                exit;
            }
            header('Location: assignments.php');
            exit;
        }
        else{
            header('Location: index.php?err=1');
            exit; 
        }
    }
    else{
        if(isset($user_email)){
            header('Location: index.php?err=1');
            exit; 
    }
  }
}
?>

    <title>Scheduler</title>
</head>

<body>
<?php if(isset($_GET["err"]) && $_GET["err"]=="1"):?>
                            <div class="alert alert-danger" role="alert">Login Failed</div>
    <?php endif;?>
    <img id="indexImage" src="IMGS/index.png" alt="index" class="rounded mx-auto d-block" style="width: 450px; height: 300px" />
    <div id="login">
        <!-- New Account -->
        <div id="newAc" class="d-grid gap-1 col-1 mx-auto">
            <button class="btn btn-primary btn-success" type="button" onclick="window.location='signup.php';">
                New Account?
            </button>
        </div>
        <!-- Email and Password -->
        <form method="POST">
        <div class="form-floating mb-3 mx-auto">
            <input type="email" class="form-control" id="user_email" name="user_email" placeholder="name@example.com" required />
            <label for="user_email">Email address</label>
        </div>
        <div class="form-floating mb-3 mx-auto">
            <input type="password" class="form-control" id="user_pass" name="user_pass" placeholder="Password" />
            <label for="user_pass">Password</label>
        </div>
        <div class="mb-3">
            <input type="checkbox" id="save_pass" name="save_pass" >  Remember Password
        </div>
        
    </div>

    <!-- Login and forgot password -->
    <div id="buttons" class="d-grid gap-2 col-6 mx-auto">
        <button id="logintbn" class="btn btn-primary" type="submit" >
            Login
        </button>
        <button class="btn btn-primary" type="button" onclick="window.location='passReset.php';">
            Forgot Password?
        </button>
    </div>
    </form>
<?php require_once("parts/footer.php");?>
</body>
</html>

<script>
    $("#lgOut").css("visibility", "hidden");
</script>